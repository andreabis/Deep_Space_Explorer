#ifndef __PLANET__
#define __PLANET__

#include <assert.h>
#include <math.h>
#include <vector>

#include "/Users/Fefy/Desktop/MAC-LINUX-texture.h"

using namespace std;

class Planet
{
private:

	float _planet_radius;						// raggio del pianeta;

	float _spinning_angle;				// angolo di rotazione del pianeta intorno al proprio asse
	float _spinning_angular_velocity;	// velocit� angolare di rotazione del pianeta intorno al proprio asse

	float _orbit_radius;				// raggio dell' orbita del pianeta
	float _orbit_angle;
	float _orbit_angular_velocity;		// velocit� angolare di rotazione del pianeta lungo la propria orbita

	Texture _planet_map;				// immagine texture map con cui colorare il pianeta
	
	GLUquadricObj *quadric;				// sfera che rappresenta il pianeta
    
    float _orbit_radius2;

public:

	Planet()	// costruttore
	{
		Init();
	}
	~Planet()	// distruttore
	{
//		gluDeleteQuadric(quadric);
	}

	vector<Planet> _satellites;

	void Init()
	{
		// inizializza le variabili private
		_planet_radius = 1.f;
		_spinning_angle = 0.f;
		_spinning_angular_velocity = 1.f;
		_orbit_radius = 0.f;
		_orbit_angle = 0.f;
		_orbit_angular_velocity = 0.f;

		// resetta il vettore dei satelliti
		_satellites.clear();
		_satellites.reserve(10 * sizeof(Planet));

		// inizializza la sfera
		quadric = gluNewQuadric();
		gluQuadricNormals(quadric, GLU_SMOOTH);	// la sfera ha le normali
		gluQuadricTexture(quadric, GL_TRUE);	// la sfera � texturizzata
	}

	void Update()
	{
		_spinning_angle += _spinning_angular_velocity;
		_orbit_angle += _orbit_angular_velocity;

		vector<Planet>::iterator pIt;
		for (pIt = _satellites.begin(); pIt != _satellites.end(); pIt++)
			pIt->Update();
	}

	void Draw()
	{
		glColor3d(0.8, 0.8, 0.9);

		glBindTexture(GL_TEXTURE_2D, _planet_map.ID);

		glPushMatrix();
			glRotatef(_orbit_angle, 0, 1, 0);
			glTranslatef(_orbit_radius, 0, 0);

			glPushMatrix();
				glRotatef(_spinning_angle, 0, 1, 0);
				glRotatef(-90,1,0,0);
				gluSphere(quadric, _planet_radius, 32, 32 );	// sfera
			glPopMatrix();

			// disegna ogni satellite con la relativa orbita
			vector<Planet>::iterator pIt;
			for (pIt = _satellites.begin(); pIt != _satellites.end(); pIt++)
			{
				// disegna orbita
				glColor3f(0.f, 0.f, 1.f);
				glDisable(GL_TEXTURE_2D);
				glBegin(GL_LINE_LOOP);
				for (float i = 0; i < 6.28; i += 0.2)
					glVertex3f(pIt->_orbit_radius * cos(i), 0, pIt->(_orbit_radius) * sin(i)); // modificare con ellissi---------
				glEnd();
				glEnable(GL_TEXTURE_2D);

				// disegna il satellite
				pIt->Draw();
			}
		glPopMatrix();
	}

	// helpers

	// inizializza la texture map da applicare al pianeta
	bool LoadTextureTGA(string texture_filename)
	{
		return _planet_map.LoadTGA((char*)texture_filename.c_str(), GL_LINEAR, GL_LINEAR);
	}

	// imposta il raggio della sfera rappresentante il pianeta
	void SetRadius(float _r)
	{
		assert(_r > 0.f);

		_planet_radius = _r;
	}

	// imposta l'angolo di rotazione iniziale del pianeta intorno al proprio asse
	// _a : angolo in gradi
	void SetSpinningAngle(float _a) {_spinning_angle = _a;	}

	// imposta la velocit� angolare di rotazione del pianeta intorno al proprio asse
	// _va : veloct� angolare in gradi/sec
	void SetSpinningAngularVelocity(float _va) {_spinning_angular_velocity = _va;	}

	// imposta il raggio dell' orbita del pianeta
	void SetOrbitRadius(float _or) {_orbit_radius = _or;	}

	// imposta l'angolo di rotazione iniziale del pianeta lungo la propria orbita
	// _oa : angolo in gradi
	void SetOrbitAngle(float _oa) {_orbit_angle = _oa;	}

	// imposta la velocit� angolare di rotazione del pianeta intorno al proprio asse
	// _va : veloct� angolare in gradi/sec
	void SetOrbitAngularVelocity(float _ova) {_orbit_angular_velocity = _ova;	}

	// aggiunge un satellite a questo pianeta
	void AddSatellite(Planet &_p)	{ _satellites.push_back(_p); }
};

#endif