#include <iostream>
#include <GLUT/glut.h>
#include <iostream>
#include <math.h>
#include <algorithm>
#include <stdarg.h>
#include <cstring>


#include "/Users/Fefy/Desktop/MAC-LINUX-texture.h"
#include "/Users/Fefy/Desktop/Solar_System/spaceship.h"
#include "planet.h"

GLint FPS = 30;		// Frame per Secondo. Vengono usati nella funzione di animazione
					// per controllare il massimo numero di frame al secondo dell'animazione

int width = 800;
int height = 600;

int spin_x = 0, old_x = 0;		// spin_ indica di quanto si deve ruotare la scena
int spin_y = 0, old_y = 0;		// old_  indica la vecchia posizione del cursore

int fase = 0;		// specifica lo stato dell' animazione
GLint n_iter = 0;
int w = 0;


Texture stars_background;
Planet sun, earth, moon, mercury, jupiter , saturn ;
Planet venus, mars, uranus, neptune ;
Planet deimos, phobos,pluto,asteroids1,asteroids2,asteroids3,asteroids4 ,asteroids5,asteroids6,asteroids7,asteroids8;
Planet asteroids9,asteroids12,asteroids13,asteroids14 ,asteroids15,asteroids16,asteroids17,asteroids18;


/*
* processa l'azione selezionata dal menu
*
* op - intero che rappresenta l'azione selezionata nel menu
*/
void menu(int op)
{
	
	switch(op)
    {
        case 'Q':
        case 'q':
		exit(0);
	}
}

/*
* invocata da GLUT quando un tasto viene premuto
*
* key - tasto premuto
* x, y - coordinate del cursore del mouse
*/
bool pause = false;
void keyPressed(unsigned char key, int x, int y) {
	
	switch(key)
    {
            
        case 'q':
            w = 1; // up
            break;
        case 'w':
            w = 2; // ahead
            break;
        case 'e':
            w = 3;
            break; // down
        case 'a':
            w = 4; // left
            break;
        case 's':
            w = 5; // back
            break;
        case 'd':
            w = 6;
            break;
            
        case ' ':
            if(pause) pause = false;
            else pause = true;
            
        case  27:   // ESC
            exit(0);
        default:
            w = 0;
            break;
	}
}

/*
* invocata da GLUT quando un tasto viene rilasciato
*
* key - tasto premuto
* x, y - coordinate del cursore del mouse
*/
void keyboardUp(unsigned char key, int x, int y) {
    }

/*
* invocata quando la finestra cambia dimensione, oppure � occlusa da un'altra finestra
* 
* width. height - dimensioni attuali della finestra
*/
void reshape(int width, int height) 
{
	GLfloat fieldOfView = 45.0f;
	glViewport (0, 0, (GLsizei) width, (GLsizei) height);
	
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fieldOfView, (GLfloat) width/(GLfloat) height, 0.1, 500.0);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

/*
* invocata quando uno dei bottoni del mouse cambia stato (viene premuto o rilasciato)
*
* button - bottone che ha cambiato stato
* state - stato attuale del bottone
* x, y - coordinate del cursore del mouse
*/
void mouseClick(int button, int state, int x, int y) 
{
	old_x = x;
	old_y = y;
	
	glutPostRedisplay();
}

/*
* invocata ogni volta che il cursore del mouse viene mosso
*
* x, y - coordinate del cursore del mouse
*
* nota: sulla maggior parte dei sistemi, la posizione del cursore del mouse viene rilevata (campionata) 
*       con una frequenza di almeno 1/30 secondi
*/
void mouseMotion(int x, int y) 
{
	spin_x = x - old_x;
	spin_y = y - old_y;
	
	glutPostRedisplay();
}

/*
* disegna gli assi
*
* lenght - lunghezza degli assi
*/
void DrawAxes(float length)
{
	glPushMatrix();
	glScalef(length, length, length);
	
	glLineWidth(2.f);
	glBegin(GL_LINES);
	
	// x red
	glColor3f(1.f, 0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	glVertex3f(1.f, 0.f, 0.f);
	
	// y green
	glColor3f(0.f, 1.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	glVertex3f(0.f, 1.f, 0.f);
	
	// z blue
	glColor3f(0.f, 0.f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	glVertex3f(0.f, 0.f, 1.f);
	
	glEnd();
	glLineWidth(1.f);
	
	glPopMatrix();
}

/*
 * disegna lo sfondo (in modalit� ortonormale)
 *
 */
void DrawBackground()
{
	// -- inizio modalit� ortografica
	glMatrixMode(GL_PROJECTION);					//seleziona projection matrix
	glPushMatrix();									//memorizza projection matrix
	glLoadIdentity();								//resetta projection matrix
	glOrtho(0, width, 0, height, -1, 1);			//imposta coordinate orto
	glMatrixMode(GL_MODELVIEW);						//seleziona modelview matrix
	
	glPushMatrix();	
	glLoadIdentity();

	glDepthMask(GL_FALSE);							// disabilita scrittura z-buffer

	glColor3f(1.f, 1.f, 1.f);
	glBindTexture(GL_TEXTURE_2D, stars_background.ID);	// usa texture stelle
	glBegin(GL_QUADS);									// disegna lo sfondo
		glTexCoord2f(0, 0);	glVertex3f(0,		0,	 0);		
		glTexCoord2f(1, 0); glVertex3f(width,	0 ,	 0);	// ad ogni vertice corrisponde un texel
		glTexCoord2f(1, 1); glVertex3f(width,	height, 0);
		glTexCoord2f(0, 1); glVertex3f(0,		height, 0);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, 0);

	glPopMatrix();									// ripristina la projection matrix vecchia
	glMatrixMode(GL_PROJECTION);					
	glPopMatrix();	
	glDepthMask(GL_TRUE);							// abilita scrittura z-buffer
	// -- fine modalit� ortogonale
}

//------------------------- draw spaceship-------------------------------



// size of the window
int window_size_x = 0, window_size_y = 0;

// implementation of printf with GLUT
//void glPrint(float* c, float x, float y, float z, const char *fmt, ...);
void glPrint(int x, int y,int z, char *string)
{
    //set the position of the text in the window using the x and y coordinates
    glRasterPos3f(x,y,z);
    //get the length of the string to display
    int len = (int) strlen(string);
    
    //loop to display character by character
    for (int i = 0; i < len; i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,string[i]);
    }
}

void output(int x, int y, char *string)
{
    glColor3f( 1, 0, 1 );
    glRasterPos2f(x, y);
    int len, i;
    len = (int)strlen(string);
    for (i = 0; i < len; i++) {
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, string[i]);
    }
}

// draw information on the screen
void DrawInfo()
{
    // -- start Ortographic Mode
    glMatrixMode(GL_PROJECTION);					//Select the projection matrix
    glPushMatrix();									//Store the projection matrix
    glLoadIdentity();								//Reset the projection matrix
    glOrtho(0, window_size_x, window_size_y, 0, -1, 1);		//Set up an ortho screen
    
    glMatrixMode(GL_MODELVIEW);						//Select the modelview matrix
    glPushMatrix();									//Store the projection matrix
    
    glLoadIdentity();								//Reset the projection matrix
    
  //  float c[3] = {0.1, 0.1, 0.1};
    float y = 25;
    
    // Display results
    
    //static double start = GetRealTimeInMS();
    //int now = GetRealTimeInMS();
    //printf("");
    output(10, y, "test"); //(10, y, 0, "Select which planet or asteroids do you want visit:"); y += 20;
    glPrint(10, y, 0, "[ 1 ] Sun   [ 2 ] Mercury   [ 3 ] Venus   [ 4 ] Earth   [ 5 ] Mars   [6] Jupiter  [ 7 ] Saturn   [ 8 ] Uranus   [9] Neptune  [10] Pluto "); y += 20;
    //glPrint(c, 10, y, 0, "iterations: %d   dt: %.3f   fps: %.2f", ps.GetNbIterations(), ps.GetTimeStep(), 1000.0 / (now - start));
    //start = now;
    
    y = 450;
    // glPrint(c, 10, y, 0, "[ Left / Right ] : Deflate / Inflate"); y += 50;
    //glPrint(c, 10, y, 0, "[ Left click + drag ] : Rotate          [ Central click + drag ] : Zoom"); y += 25;
    //glPrint(c, 10, y, 0, "[ Right click + drag ] : Grab and pull a particle"); y += 25;
    //glPrint(c, 10, y, 0, "[ Space ] : Freeze / Continue the simulation "); y += 25;
    //glPrint(c, 10, y, 0, "Coded by Marco Fratarcangeli for Game Programming Gems 8"); y += 25;
    
    glPopMatrix();									//Restore the old projection matrix
    glMatrixMode(GL_PROJECTION);					//Select the projection matrix
    glPopMatrix();									//Restore the old projection matrix
    glMatrixMode(GL_MODELVIEW);
    // -- end Ortographic mode
}



void display_planet() //draw bb
{
    glClearColor(1.0f, 0.0f, 1.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3f(0.0f, 0.0f, 0.0f);
    
    //glPushMatrix();
     //glPopMatrix();
    
    DrawInfo();
    
       
    glutSwapBuffers();
    
}

void reshape_planet(GLsizei w, GLsizei h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-0.5, 0.5, -0.5, 0.5, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(3.0, 3.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0,
              0.0);
}





//---------------------------------------------------------------------------

/*
* disegna la scena
 */
int x = 1;
int y = 15;
int z = 15;
void draw() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	DrawBackground();
  //  make_base();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt(  25, 25, 25,		// da dove si guarda
				0, 0, 0,		// dove si guarda
				0, 1, 0);		// su
	
	glTranslatef(-3.f, -3.f, -3.f);
	glRotatef(spin_y, 1.0, 0.0, 0.0);
	glRotatef(spin_x, 0.0, 1.0, 0.0);
    
    glPushMatrix();
	
//-----------------------------------------------------------------------------
    
/*
 * movimento astronave
 */
    spaceship ss;
    switch (w)
    {
        case 1:
            y += 1;
            break;
        case 2:
            z += 1;
            break;
        case 3:
            y -= 1;
            break;
        case 4:
            x -= 1;
            break;
        case 5:
            z -= 1;
            break;
        case 6:
            x += 1;
            break;
        default:
            break;
    }
     
    ss.draw_spaceship(x,y,z);
    w = 0;

    
	DrawAxes(4.0);
    if(!pause) sun.Draw();
    
    
    glPopMatrix();
    glFlush();
    
    DrawInfo();

    
	glutSwapBuffers();
}



/*
* invocata ogni volta che non ci sono eventi pendenti da processare
*/
void idle() { }


/*
* invocata ogni 1000/FPS millisecondi.
* all' interno di questa funzione va cambiato lo stato degli oggetti della scena al fine, ad esempio, di animarli.
* quando lo stato cambia, si deve chiamare glutPostRedisplay() per aggiornare la visualizzazione il prima possibile
* (cio� quando tutti gli eventi pendenti sono stati processati).
*
* t - � il parametro definito dall' utente specificato per ultimo nella glutTimerFunc
*/

GLfloat corpo_x = -20;
double x_shapeship; double y_shapeship; double z_shapeship;

void animation(int t)
{
	switch (fase) {
        case 0:
             sun.Update();
            fase++;
            break;
            
        case 1: // prima fase di animazione
           
            for ( float x = 0; x < 60; x++ ){
                x_shapeship += 500;
            }
            fase++;
             sun.Update();
            break;
            
        case 2:
            
            for ( float x = 0; x < 60; x++ ){
                x_shapeship += 1.0;
            }
            fase++;
             sun.Update();
            break;
        case 3:
    
            for ( float x = 0; x < 60; x++ ){
                x_shapeship += 2.5;
            } sun.Update();
            fase++;
            break;
        case 4:
            
            for ( float x = 0; x < 60; x++ ){
                x_shapeship += 3.0;
            } sun.Update();
            fase++;
            break;
        case 5: 
            
            for ( float x = 0; x < 60; x++ ){
                x_shapeship += 4;
            } sun.Update();
            fase++;
            break;
            
        default:
            sun.Update();
            fase=0;
            break;
    
            
        
    }
	//glutTimerFunc((int) 1000/FPS, animation, 0);
	// La glutTimerFunc funziona come una sveglia che squilla una volta dopo x millisecondi. 
	// Se si vuole che suoni (si richiami) di nuovo bisogn ri-invocarla
	
	glutPostRedisplay();
    glutTimerFunc((int) 1000/FPS, animation, 0);

}

void fuel(double r1, double r2, double m1)
{
    double const nepero = 2.71828183;
    double const Ve = 9.81 * 5000;
    double const Mu = 132712440018;
    double deltaV1 = sqrt(Mu/r1) * ( sqrt( ( 2 * r2 ) / (r1 + r2) ) - 1);
    double deltaV2 = sqrt(Mu/r2) * (1 - sqrt( ( 2 * r1 ) / (r1 + r2) ));
    double deltaVT =  (deltaV1 + deltaV2);
    //float m0 = nepero^(deltaVT/ Ve);
    //fuel = m1 - m0;
    
}

/*
* inizializza lo stato di OpenGL
*
* width, height - larghezza e altezza della finestra OpenGL
*/
void initGL(int width, int height) 
{
	// colore e tipo delle luci	
	GLfloat light_ambient_0[] =	{0.65, 0.65, 0.65, 1.0};// colore ambiente della luce 0
	GLfloat light_diffuse_0[] = {1.0, 1.0, 1.0, 1.0};	// colore diffusione della luce 0
	GLfloat light_specular_0[] = {1.0, 1.0, 1.0, 1.0};	// colore speculare della luce 0
	GLfloat light_position_0[] = {15.0, 5.0, 10.0, 0.0};	// posizione della luce 0
	
	glLightfv (GL_LIGHT0, GL_AMBIENT,	light_ambient_0);
	glLightfv (GL_LIGHT0, GL_DIFFUSE,	light_diffuse_0);
	glLightfv (GL_LIGHT0, GL_SPECULAR,	light_specular_0);
	glLightfv (GL_LIGHT0, GL_POSITION,	light_position_0);
	
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
	
	reshape(width, height);
	
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	
	glEnable(GL_TEXTURE_2D);
	
    //earth
	if (!earth.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/earthmap1k.tga"))
	{
		printf("failed to load earth texture!\n");
		exit(0);
	}
	earth.SetRadius(1.f);
	earth.SetSpinningAngle(0);
	earth.SetSpinningAngularVelocity(1);
	earth.SetOrbitRadius(15);
	earth.SetOrbitAngle(0);
	earth.SetOrbitAngularVelocity(2);

    //moon
	if (!moon.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	moon.SetRadius(.3f);
	moon.SetSpinningAngle(0);
	moon.SetSpinningAngularVelocity(1);
	moon.SetOrbitRadius(2);
	moon.SetOrbitAngle(0);
	moon.SetOrbitAngularVelocity(5);

	earth.AddSatellite(moon);

    //venus
	if (!venus.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/venusmap.tga"))
	{
		printf("failed to load venus texture!\n");
		exit(0);
	}
	venus.SetRadius(.75f);
	venus.SetSpinningAngle(0);
	venus.SetSpinningAngularVelocity(1);
	venus.SetOrbitRadius(10);
	venus.SetOrbitAngle(0);
	venus.SetOrbitAngularVelocity(4);
    
    //mars
	if (!mars.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/marsmap.tga"))
	{
		printf("failed to load mars texture!\n");
		exit(0);
	}
	mars.SetRadius(1.25f);
	mars.SetSpinningAngle(0);
	mars.SetSpinningAngularVelocity(1.5);
	mars.SetOrbitRadius(20);
	mars.SetOrbitAngle(0);
	mars.SetOrbitAngularVelocity(1);
    
    //------------------------------------------------------------------
    //draw Asteroid Belt
	if (!asteroids1.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids1.SetRadius(.25f);
	asteroids1.SetSpinningAngle(0);
	asteroids1.SetSpinningAngularVelocity(1);
	asteroids1.SetOrbitRadius(21);
	asteroids1.SetOrbitAngle(0);
	asteroids1.SetOrbitAngularVelocity(5.98);
    
    //draw Asteroid Belt
	if (!asteroids2.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids2.SetRadius(.25f);
	asteroids2.SetSpinningAngle(0);
	asteroids2.SetSpinningAngularVelocity(1);
	asteroids2.SetOrbitRadius(21.5);
	asteroids2.SetOrbitAngle(0);
	asteroids2.SetOrbitAngularVelocity(5.99);
    
    //draw Asteroid Belt
	if (!asteroids3.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids3.SetRadius(.25f);
	asteroids3.SetSpinningAngle(0);
	asteroids3.SetSpinningAngularVelocity(1);
	asteroids3.SetOrbitRadius(22);
	asteroids3.SetOrbitAngle(0);
	asteroids3.SetOrbitAngularVelocity(6);
    
    //draw Asteroid Belt
	if (!asteroids4.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids4.SetRadius(.25f);
	asteroids4.SetSpinningAngle(0);
	asteroids4.SetSpinningAngularVelocity(1);
	asteroids4.SetOrbitRadius(22.5);
	asteroids4.SetOrbitAngle(0);
	asteroids4.SetOrbitAngularVelocity(5.97);
    
    if (!asteroids5.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
    asteroids5.SetRadius(.25f);
	asteroids5.SetSpinningAngle(0);
	asteroids5.SetSpinningAngularVelocity(1);
	asteroids5.SetOrbitRadius(21);
	asteroids5.SetOrbitAngle(0);
	asteroids5.SetOrbitAngularVelocity(5.99);
    
    //draw Asteroid Belt
	if (!asteroids6.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids6.SetRadius(.25f);
	asteroids6.SetSpinningAngle(0);
	asteroids6.SetSpinningAngularVelocity(1);
	asteroids6.SetOrbitRadius(21.5);
	asteroids6.SetOrbitAngle(0);
	asteroids6.SetOrbitAngularVelocity(5.98);
    
    //draw Asteroid Belt
	if (!asteroids7.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids7.SetRadius(.25f);
	asteroids7.SetSpinningAngle(0);
	asteroids7.SetSpinningAngularVelocity(1);
	asteroids7.SetOrbitRadius(22);
	asteroids7.SetOrbitAngle(0);
	asteroids7.SetOrbitAngularVelocity(6);
    
    //draw Asteroid Belt
	if (!asteroids8.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids8.SetRadius(.25f);
	asteroids8.SetSpinningAngle(0);
	asteroids8.SetSpinningAngularVelocity(1);
	asteroids8.SetOrbitRadius(22.5);
	asteroids8.SetOrbitAngle(0);
	asteroids8.SetOrbitAngularVelocity(5.96);
    
    if (!asteroids9.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids9.SetRadius(.25f);
	asteroids9.SetSpinningAngle(0);
	asteroids9.SetSpinningAngularVelocity(1);
	asteroids9.SetOrbitRadius(21);
	asteroids9.SetOrbitAngle(0);
	asteroids9.SetOrbitAngularVelocity(5.99);
    
    //draw Asteroid Belt
	if (!asteroids12.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids12.SetRadius(.25f);
	asteroids12.SetSpinningAngle(0);
	asteroids12.SetSpinningAngularVelocity(1);
	asteroids12.SetOrbitRadius(21.5);
	asteroids12.SetOrbitAngle(0);
	asteroids12.SetOrbitAngularVelocity(5.97);
    
    //draw Asteroid Belt
	if (!asteroids13.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids13.SetRadius(.25f);
	asteroids13.SetSpinningAngle(0);
	asteroids13.SetSpinningAngularVelocity(1);
	asteroids13.SetOrbitRadius(22);
	asteroids13.SetOrbitAngle(0);
	asteroids13.SetOrbitAngularVelocity(5.99);
    
    //draw Asteroid Belt
	if (!asteroids14.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids14.SetRadius(.25f);
	asteroids14.SetSpinningAngle(0);
	asteroids14.SetSpinningAngularVelocity(1);
	asteroids14.SetOrbitRadius(22.5);
	asteroids14.SetOrbitAngle(0);
	asteroids14.SetOrbitAngularVelocity(5.97);
    
    if (!asteroids15.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
    asteroids15.SetRadius(.25f);
	asteroids15.SetSpinningAngle(0);
	asteroids15.SetSpinningAngularVelocity(1);
	asteroids15.SetOrbitRadius(21);
	asteroids15.SetOrbitAngle(0);
	asteroids15.SetOrbitAngularVelocity(5.99);
    

	if (!asteroids16.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids16.SetRadius(.25f);
	asteroids16.SetSpinningAngle(0);
	asteroids16.SetSpinningAngularVelocity(1);
	asteroids16.SetOrbitRadius(21.5);
	asteroids16.SetOrbitAngle(0);
	asteroids16.SetOrbitAngularVelocity(5.97);
    
    //draw Asteroid Belt
	if (!asteroids17.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids17.SetRadius(.25f);
	asteroids17.SetSpinningAngle(0);
	asteroids17.SetSpinningAngularVelocity(1);
	asteroids17.SetOrbitRadius(22);
	asteroids17.SetOrbitAngle(0);
	asteroids17.SetOrbitAngularVelocity(5.99);
    
    //draw Asteroid Belt
	if (!asteroids18.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	asteroids18.SetRadius(.25f);
	asteroids18.SetSpinningAngle(0);
	asteroids18.SetSpinningAngularVelocity(1);
	asteroids18.SetOrbitRadius(22.5);
	asteroids18.SetOrbitAngle(0);
	asteroids18.SetOrbitAngularVelocity(5.97);
    
    


    
    //----------------------------------------------------------
    
	if (!deimos.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load deimos texture!\n");
		exit(0);
	}
	deimos.SetRadius(.3f);
	deimos.SetSpinningAngle(0);
	deimos.SetSpinningAngularVelocity(1);
	deimos.SetOrbitRadius(3);
	deimos.SetOrbitAngle(0);
	deimos.SetOrbitAngularVelocity(5);

	if (!phobos.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to phobos texture!\n");
		exit(0);
	}
	phobos.SetRadius(.3f);
	phobos.SetSpinningAngle(0);
	phobos.SetSpinningAngularVelocity(1);
	phobos.SetOrbitRadius(4);
	phobos.SetOrbitAngle(0);
	phobos.SetOrbitAngularVelocity(7);

	mars.AddSatellite(deimos);
	mars.AddSatellite(phobos);
    
    //mercury
    if (!mercury.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/mercury.tga"))
	{
		printf("failed to load venus texture!\n");
		exit(0);
	}
	mercury.SetRadius(.5f);
	mercury.SetSpinningAngle(0);
	mercury.SetSpinningAngularVelocity(1);
	mercury.SetOrbitRadius(8);
	mercury.SetOrbitAngle(0);
	mercury.SetOrbitAngularVelocity(4);
    
    //jupiter
    if (!jupiter.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/jupitermap.tga"))
	{
		printf("failed to load venus texture!\n");
		exit(0);
	}
	jupiter.SetRadius(2.5f);
	jupiter.SetSpinningAngle(0);
	jupiter.SetSpinningAngularVelocity(1);
	jupiter.SetOrbitRadius(25);
	jupiter.SetOrbitAngle(0);
	jupiter.SetOrbitAngularVelocity(4);
    
    //saturn
    if (!saturn.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/saturnmap.tga"))
	{
		printf("failed to load venus texture!\n");
		exit(0);
	}
	saturn.SetRadius(2.5f);
	saturn.SetSpinningAngle(0);
	saturn.SetSpinningAngularVelocity(1);
	saturn.SetOrbitRadius(35);
	saturn.SetOrbitAngle(0);
	saturn.SetOrbitAngularVelocity(4);
    
    //uranus
	if (!uranus.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/uranusmap.tga"))
	{
		printf("failed to load earth texture!\n");
		exit(0);
	}
	uranus.SetRadius(2.f);
	uranus.SetSpinningAngle(0);
	uranus.SetSpinningAngularVelocity(1);
	uranus.SetOrbitRadius(40);
	uranus.SetOrbitAngle(0);
	uranus.SetOrbitAngularVelocity(2);
    
    //neptune
	if (!neptune.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/neptunemap.tga"))
	{
		printf("failed to load earth texture!\n");
		exit(0);
	}
	neptune.SetRadius(2.f);
	neptune.SetSpinningAngle(0);
	neptune.SetSpinningAngularVelocity(1);
	neptune.SetOrbitRadius(45);
	neptune.SetOrbitAngle(0);
	neptune.SetOrbitAngularVelocity(2);
    
    //pluto
	if (!pluto.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/moonmap4k.tga"))
	{
		printf("failed to load moon texture!\n");
		exit(0);
	}
	pluto.SetRadius(.3f);
	pluto.SetSpinningAngle(0);
	pluto.SetSpinningAngularVelocity(1);
	pluto.SetOrbitRadius(48);
	pluto.SetOrbitAngle(0);
	pluto.SetOrbitAngularVelocity(5);
    

	if (!sun.LoadTextureTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/sunmap.tga"))
	{
		printf("failed to load sun texture!\n");
		exit(0);
	}
	sun.SetRadius(5.f);
	sun.SetSpinningAngle(0);
	sun.SetSpinningAngularVelocity(0.25);
	sun.SetOrbitRadius(0);
	sun.SetOrbitAngle(0);
	sun.SetOrbitAngularVelocity(0);

	sun.AddSatellite(earth);
	sun.AddSatellite(venus);
	sun.AddSatellite(mars);
    sun.AddSatellite(asteroids1);
    sun.AddSatellite(asteroids2);
    sun.AddSatellite(asteroids3);
    sun.AddSatellite(asteroids4);
    sun.AddSatellite(asteroids5);
    sun.AddSatellite(asteroids6);
    sun.AddSatellite(asteroids7);
    sun.AddSatellite(asteroids8);
    sun.AddSatellite(asteroids9);
    sun.AddSatellite(asteroids12);
    sun.AddSatellite(asteroids13);
    sun.AddSatellite(asteroids14);
    sun.AddSatellite(asteroids15);
    sun.AddSatellite(asteroids16);
    sun.AddSatellite(asteroids17);
    sun.AddSatellite(asteroids18);
   
    sun.AddSatellite(mercury);
    sun.AddSatellite(jupiter);
    sun.AddSatellite(saturn);
    sun.AddSatellite(uranus);
    sun.AddSatellite(neptune);
    sun.AddSatellite(pluto);
    

	stars_background.LoadTGA("/Users/Fefy/Desktop/Solar_System/Solar_System/data/stars_3.tga", GL_LINEAR, GL_LINEAR);
    
}


#define MENU_A    1                  /* menu option identifiers */
#define MENU_B    2
#define MENU_C    3
#define MENU_D    4
#define MENU_E    5
#define MENU_F    6
#define MENU_G    7
#define MENU_H    8


#define MENU_QUIT 9
void menuCB(int item)
{
    switch (item) {                     /* process the popup menu commands */
        case MENU_A:
            /* process menu option A... */
            break;
        case MENU_B:
            /* process menu option B... */
            break;
        case MENU_C:
            /* process menu option C... */
            break;
        case MENU_D:
            /* process menu option D... */
            break;
        case MENU_E:
            /* process menu option D... */
            break;
        case MENU_F:
            /* process menu option C... */
            break;
        case MENU_G:
            /* process menu option D... */
            break;
        case MENU_H:
            /* process menu option D... */
            break;
        case MENU_QUIT:
            exit(0);                          /* quit the program */
            break;
    }
}

void specialDown(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_LEFT:
            spaceship ss;
            ss.draw_spaceship(5, 10, 10);
            
           
            break;
            
        case GLUT_KEY_RIGHT:
           
            break;
        default:
           // spaceship ss;
            ss.draw_spaceship(5, 10, 10);
            break;
            
    }
    
    glutPostRedisplay();
}



int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Solar System");
	
	// registra le callback
	glutKeyboardFunc(keyPressed);
	glutKeyboardUpFunc(keyboardUp);
    glutSpecialFunc(specialDown);
	glutMouseFunc(mouseClick);
	glutMotionFunc(mouseMotion);
	glutReshapeFunc(reshape);
	glutDisplayFunc(draw);  
	glutIdleFunc(idle);
	glutTimerFunc((int) 1000/FPS, animation, 0);
	glutIgnoreKeyRepeat(false); // process keys held down
	
        
    //---------------
    int sub4 = glutCreateMenu(menuCB);
    glutAddMenuEntry("Hard", MENU_H);
    glutAddMenuEntry("Medium", MENU_G);
    glutAddMenuEntry("Easy", MENU_F);
    
    
    int sub3 = glutCreateMenu(menuCB);
    glutAddMenuEntry("Navicella Rossa", MENU_E);
    glutAddMenuEntry("Navicella Gialla", MENU_D);
    glutAddMenuEntry("Navicella Verde", MENU_C);
    glutAddSubMenu("Missione",  sub4);
    
    int sub2 = glutCreateMenu(menuCB);
    glutAddSubMenu("Navicella o Missione",sub3);
    
   int sub1 = glutCreateMenu(menuCB);
    glutAddMenuEntry("Continue", MENU_A);
    glutAddSubMenu("New Game",  sub2);
    
    glutCreateMenu(menuCB);
    glutAddSubMenu("Play",  sub1);
    glutAddMenuEntry("Quit",     MENU_QUIT);
    
    glutAttachMenu(GLUT_RIGHT_BUTTON); /* tie popup menu to right mouse button */

    //----------------
  
	// inizializza lo stato di OpenGL
	initGL(width, height);



	
	// entra nel rendering loop	
	glutMainLoop();
	return 0;
}