//
//  spaceship.h
//  Solar_System
//
//  Created by Fefy on 13/04/14.
//  Copyright (c) 2014 Fefy. All rights reserved.
//

#ifndef Solar_System_spaceship_h
#define Solar_System_spaceship_h



class spaceship
{
    public:

    double storage; //spaceship's capability
    double life;
    double free_space; //inside our storage
   // std::vector< list < int > > arr(sizeof, list < int > ()); //

   
   GLUquadric *myQuad;
    
    void draw_spaceship(double x_shapeship, double y_shapeship, double z_shapeship)
    {
        glPushMatrix();
        
        glScalef(0.6,0.7,0.7);
        glTranslatef(x_shapeship, y_shapeship, z_shapeship);
        glRotatef(90, 0, 0, 1);
        
        glColor3f(1.0, 1.0, 1.0);
        glutWireSphere(2.0,5.0,6.0);
        
    
        glColor3f(1.0, 0.0, 0.0);
        glRotatef(90, 1, 0, 0);
        glutWireSphere(0.2, 2.0, 2.0);
        myQuad = gluNewQuadric();
        gluSphere(myQuad, 0.4, 2.0, 2.0);
        
        glColor3f(1.0, 0.0, 0.0);
        glRotatef(90, 1, 0, 0);
        glTranslatef(0.1, 0.0, 0.0);
        myQuad = gluNewQuadric();
        gluSphere(myQuad, 0.4, 2.0, 2.0);
        
        glColor3f(1.0, 0.0, 0.0);
        glRotatef(90, 1, 0, 0);
        glTranslatef(-0.05, 0.0, 0.0);
        myQuad = gluNewQuadric();
        gluSphere(myQuad, 0.4, 2.0, 2.0);
        
        glColor3f(1.0, 0.0, 0.0);
        glRotatef(90, 1, 0, 0);
        glTranslatef(-0.1, 0.0, 0.0);
        myQuad = gluNewQuadric();
        gluSphere(myQuad, 0.4, 2.0, 2.0);
      
        
        glPopMatrix();
        
        
    }//end make_base
    

    
};
#endif
